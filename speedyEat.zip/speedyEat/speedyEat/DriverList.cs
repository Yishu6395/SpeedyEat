﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace SpeedyEat
{
    public class DriverList
    {
        public List<Driver> Drivers { get; }

        public DriverList()
        {
            this.Drivers = new List<Driver>();
        }

        public List<String> CalculateDateDistances()
        {
            var dateDistancesList = new List<string>();

            var dateTotals =
                from driver in this.Drivers
                from journey in driver.Journeys
                group journey by journey.Date into dates
                let totalDistances = (from jour in dates select (int)jour.Distances).Sum()
                orderby dates.Key ascending
                select new
                {
                    DateName = dates.Key,
                    TotalDistances = totalDistances
                };

            foreach (var p in dateTotals)
            {
                dateDistancesList.Add(String.Format("{0}: Distance = {1}", p.DateName, p.TotalDistances));

            }

            return dateDistancesList;
        }

        public List<String> CalculateAlphabet()
        {
            var ans = new List<string>();


            var driverTotals =
                from driver in this.Drivers
                let totalDistance = (from jour in driver.Journeys select jour.Distances).Sum()
                select new
                {
                    DriverName = driver.Name,
                    TotalDistances = totalDistance
                };

            foreach (var p in driverTotals)
            {
                ans.Add(String.Format("{0}: Distance = {1}", p.DriverName, p.TotalDistances));
            } 
            ans.Sort();

            return ans;
        }

        public List<String> CalculateLongest()
        {
            var dist = 0;
            var date = "";
            var name = "";

            foreach(var driver in this.Drivers)
            {
                if(dist < driver.longestDistance)
                {
                    dist = driver.longestDistance;
                    date = driver.longestDate;
                    name = driver.Name;
                }
            }
            List<String> ans = new List<String>();
            ans.Add("Longest Distance up till now ");
            ans.Add(String.Format("Driver Name : {0}", name));
            ans.Add(String.Format("Distance = {0}", dist));
            ans.Add(String.Format("Date : {0}", date));
            return ans;

        }
    }
}
