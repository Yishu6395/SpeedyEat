﻿using System;

namespace SpeedyEat
{
    public class Journey
    {
        public String Date { get; }
        public String Collection { get; }
        public String Delivery { get; }
        public int Distances { get; }

        public Journey(String date, String collection, String delivery, int distances)
        {
            this.Date = date;
            this.Collection = collection;
            this.Delivery = delivery;
            this.Distances = distances;
        }

        public override String ToString()
        {
            return string.Format("{0}: {1}, {2}, {3}", this.Date, this.Collection, this.Delivery, this.Distances);
        }
    }
}
