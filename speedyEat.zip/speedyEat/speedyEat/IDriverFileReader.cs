﻿namespace SpeedyEat
{
    public interface IDriverFileReader
    {
        Driver ReadDriverDataFromFile(ConfigRecord configRecord);
    }
}
