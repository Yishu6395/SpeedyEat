﻿using System;
using System.Linq;
using System.IO;
using System.Xml.Linq;
using SpeedyEat;

namespace SpeedyEat
{
    public class XMLDriverFileReader : IDriverFileReader
    {
        public Driver ReadDriverDataFromFile(ConfigRecord configRecord)
        {
            // Open the file to read from on the local file system, if this file is missing then return
            // immediately from this method
            if (!File.Exists(configRecord.Filename))
            {
                // Cannot open the file as it does not exist for whatever reason, so return immediately.
                return null;
            }

            // Open file and load into memory as XML
            XDocument xmlDoc = XDocument.Load(configRecord.Filename);

            // Create driver (should only be one in file but retrieve first to be sure)
            var con = (from c in xmlDoc.Descendants("Driver")
                       select c).First();

            Driver driver = new Driver(con.Attribute("name").Value, 0, "");

            // Obtain journeys from this driver
            var jour = from c in con.Descendants("Journey")
                       select c;

            foreach (var c in jour)
            {
                var date = c.Attribute("date").Value;
                var collection = c.Element("Collection").Value;
                var lastame = c.Element("Delivery").Value;
                var distances = Int32.Parse(c.Element("Distance").Value);
                if(distances > driver.longestDistance)
                {
                    driver.longestDistance = distances;
                    driver.longestDate = date;
                }

                Journey journey = new Journey(date, collection, lastame, distances);
                driver.Journeys.Add(journey);
            }

            return driver;
        }
    }
}
