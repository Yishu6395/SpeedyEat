﻿using System;
using System.Collections.Generic;

namespace SpeedyEat
{
    public class Driver
    {
        public String Name { get; }
        public int longestDistance { get; set; }
        public String longestDate { get; set; }

        public List<Journey> Journeys { get; }

        public Driver(String name, int longestDistance, String longestDate)
        {
            this.Name = name;
            this.Journeys = new List<Journey>();
            this.longestDistance = longestDistance;
            this.longestDate = longestDate;
        }

        public override String ToString()
        {
            return String.Format("Driver: {0}", this.Name);
        }
    }
}
