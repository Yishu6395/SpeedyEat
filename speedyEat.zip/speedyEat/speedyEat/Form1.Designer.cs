﻿namespace SpeedyEat
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.configBtn = new System.Windows.Forms.Button();
            this.RunProducerConsumerBtn = new System.Windows.Forms.Button();
            this.progressLbl = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.driverListbox = new System.Windows.Forms.ListBox();
            this.driverBtn = new System.Windows.Forms.Button();
            this.datesBtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.reportLbl = new System.Windows.Forms.Label();
            this.journeyListbox = new System.Windows.Forms.ListBox();
            this.dateListbox = new System.Windows.Forms.ListBox();
            this.AlphabetBtn = new System.Windows.Forms.Button();
            this.longestBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // configBtn
            // 
            this.configBtn.Location = new System.Drawing.Point(33, 27);
            this.configBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.configBtn.Name = "configBtn";
            this.configBtn.Size = new System.Drawing.Size(255, 39);
            this.configBtn.TabIndex = 0;
            this.configBtn.Text = "Create Config Data";
            this.configBtn.UseVisualStyleBackColor = true;
            this.configBtn.Click += new System.EventHandler(this.configBtn_Click);
            // 
            // RunProducerConsumerBtn
            // 
            this.RunProducerConsumerBtn.Enabled = false;
            this.RunProducerConsumerBtn.Location = new System.Drawing.Point(33, 90);
            this.RunProducerConsumerBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.RunProducerConsumerBtn.Name = "RunProducerConsumerBtn";
            this.RunProducerConsumerBtn.Size = new System.Drawing.Size(255, 36);
            this.RunProducerConsumerBtn.TabIndex = 1;
            this.RunProducerConsumerBtn.Text = "Load Journey Data";
            this.RunProducerConsumerBtn.UseVisualStyleBackColor = true;
            this.RunProducerConsumerBtn.Click += new System.EventHandler(this.RunProducerConsumerBtn_Click);
            // 
            // progressLbl
            // 
            this.progressLbl.AutoSize = true;
            this.progressLbl.Location = new System.Drawing.Point(384, 27);
            this.progressLbl.Name = "progressLbl";
            this.progressLbl.Size = new System.Drawing.Size(89, 16);
            this.progressLbl.TabIndex = 2;
            this.progressLbl.Text = "Awaiting Data";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(313, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(47, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "Status:";
            // 
            // driverListbox
            // 
            this.driverListbox.FormattingEnabled = true;
            this.driverListbox.ItemHeight = 16;
            this.driverListbox.Location = new System.Drawing.Point(331, 116);
            this.driverListbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.driverListbox.Name = "driverListbox";
            this.driverListbox.Size = new System.Drawing.Size(331, 228);
            this.driverListbox.TabIndex = 4;
            this.driverListbox.SelectedIndexChanged += new System.EventHandler(this.driverListbox_SelectedIndexChanged);
            // 
            // driverBtn
            // 
            this.driverBtn.Enabled = false;
            this.driverBtn.Location = new System.Drawing.Point(33, 156);
            this.driverBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.driverBtn.Name = "driverBtn";
            this.driverBtn.Size = new System.Drawing.Size(180, 39);
            this.driverBtn.TabIndex = 5;
            this.driverBtn.Text = "Display Drivers";
            this.driverBtn.UseVisualStyleBackColor = true;
            this.driverBtn.Click += new System.EventHandler(this.driversBtn_Click);
            // 
            // datesBtn
            // 
            this.datesBtn.Enabled = false;
            this.datesBtn.Location = new System.Drawing.Point(33, 254);
            this.datesBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.datesBtn.Name = "datesBtn";
            this.datesBtn.Size = new System.Drawing.Size(180, 39);
            this.datesBtn.TabIndex = 6;
            this.datesBtn.Text = "Display Date Distances";
            this.datesBtn.UseVisualStyleBackColor = true;
            this.datesBtn.Click += new System.EventHandler(this.datesBtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(331, 90);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 16);
            this.label2.TabIndex = 7;
            this.label2.Text = "Drivers";
            // 
            // reportLbl
            // 
            this.reportLbl.AutoSize = true;
            this.reportLbl.Location = new System.Drawing.Point(500, 90);
            this.reportLbl.Name = "reportLbl";
            this.reportLbl.Size = new System.Drawing.Size(0, 16);
            this.reportLbl.TabIndex = 8;
            // 
            // journeyListbox
            // 
            this.journeyListbox.FormattingEnabled = true;
            this.journeyListbox.ItemHeight = 16;
            this.journeyListbox.Location = new System.Drawing.Point(665, 116);
            this.journeyListbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.journeyListbox.Name = "journeyListbox";
            this.journeyListbox.Size = new System.Drawing.Size(327, 228);
            this.journeyListbox.TabIndex = 9;
            // 
            // dateListbox
            // 
            this.dateListbox.FormattingEnabled = true;
            this.dateListbox.ItemHeight = 16;
            this.dateListbox.Location = new System.Drawing.Point(996, 116);
            this.dateListbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dateListbox.Name = "dateListbox";
            this.dateListbox.Size = new System.Drawing.Size(284, 228);
            this.dateListbox.TabIndex = 10;
            // 
            // AlphabetBtn
            // 
            this.AlphabetBtn.Enabled = false;
            this.AlphabetBtn.Location = new System.Drawing.Point(33, 199);
            this.AlphabetBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.AlphabetBtn.Name = "AlphabetBtn";
            this.AlphabetBtn.Size = new System.Drawing.Size(180, 51);
            this.AlphabetBtn.TabIndex = 11;
            this.AlphabetBtn.Text = "Display Drivers Alphabetically";
            this.AlphabetBtn.UseVisualStyleBackColor = true;
            this.AlphabetBtn.Click += new System.EventHandler(this.AlphabetBtn_Click);
            // 
            // longestBtn
            // 
            this.longestBtn.Enabled = false;
            this.longestBtn.Location = new System.Drawing.Point(33, 305);
            this.longestBtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.longestBtn.Name = "longestBtn";
            this.longestBtn.Size = new System.Drawing.Size(180, 39);
            this.longestBtn.TabIndex = 12;
            this.longestBtn.Text = "Display Longest Journey";
            this.longestBtn.UseVisualStyleBackColor = true;
            this.longestBtn.Click += new System.EventHandler(this.longestBtn_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1308, 369);
            this.Controls.Add(this.longestBtn);
            this.Controls.Add(this.AlphabetBtn);
            this.Controls.Add(this.dateListbox);
            this.Controls.Add(this.journeyListbox);
            this.Controls.Add(this.reportLbl);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.datesBtn);
            this.Controls.Add(this.driverBtn);
            this.Controls.Add(this.driverListbox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.progressLbl);
            this.Controls.Add(this.RunProducerConsumerBtn);
            this.Controls.Add(this.configBtn);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "SpeedyEat GUI";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button configBtn;
        private System.Windows.Forms.Button RunProducerConsumerBtn;
        private System.Windows.Forms.Label progressLbl;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox driverListbox;
        private System.Windows.Forms.Button driverBtn;
        private System.Windows.Forms.Button datesBtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label reportLbl;
        private System.Windows.Forms.ListBox journeyListbox;
        private System.Windows.Forms.ListBox dateListbox;
        private System.Windows.Forms.Button AlphabetBtn;
        private System.Windows.Forms.Button longestBtn;
    }
}

