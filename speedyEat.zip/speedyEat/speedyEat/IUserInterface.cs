﻿namespace SpeedyEat
{
    public interface IUserInterface
    {
        void SetupConfigData();
        void RunProducerConsumer();
        void DisplayDrivers();
    }
}