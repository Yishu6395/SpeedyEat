﻿using System;
using System.Threading;
using System.Windows;
using System.Windows.Forms;

namespace SpeedyEat
{
    public partial class Form1 : Form, IUserInterface
    {
        public IDriverFileReader IOhandler { get; }
        private ConfigData configData;
        private DriverList driverList;

        public Form1(IDriverFileReader IOhandler)
        {
            InitializeComponent();
            this.IOhandler = IOhandler;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        public void SetupConfigData()
        {
            // Make sure configData is a new empty object
            configData = new ConfigData();

            // Generate configuration data using filename for each driver XML file - note: the actual
            // XML files must be located in the bin/Debug folder of the project (so they can be found)
            configData.configRecords.Add(new ConfigRecord("Driver-01.xml"));
            configData.configRecords.Add(new ConfigRecord("Driver-02.xml"));
            configData.configRecords.Add(new ConfigRecord("Driver-03.xml"));
            configData.configRecords.Add(new ConfigRecord("Driver-04.xml"));
            configData.configRecords.Add(new ConfigRecord("Driver-05.xml"));
            configData.configRecords.Add(new ConfigRecord("Driver-06.xml"));
        }

        public void RunProducerConsumer()
        {
            //Create driver list to hold individual Driver objects read from XML files
            driverList = new DriverList();

            // Create progress manager with number of files to process
            var progManager = new ProgressManager(configData.configRecords.Count);

            // Create a PCQueue instance, give it a capacity of 4
            var pcQueue = new PCQueue(4);

            // Create 2 Producer instances and 2 Consumer instances, these will begin executing on
            // their respective threads as soon as they are instantiated
            Producer[] producers = { new Producer("P1", pcQueue, configData, IOhandler),
                                     new Producer("P2", pcQueue, configData, IOhandler) };

            Consumer[] consumers = { new Consumer("C1", pcQueue, driverList, progManager),
                                     new Consumer("C2", pcQueue, driverList, progManager) };

            // Keep producing and consuming until all work items are completed
            while (progManager.ItemsRemaining > 0) ;

            // Deactivate the PCQueue so it does not prevent waiting producer and/or consumer threads
            // from completing
            pcQueue.Active = false;

            // Iterate through consumers and signal them to finish
            foreach (var c in consumers)
            {
                c.Finished = true;
            }

            // Wait for all consumers to finish
            while (Consumer.RunningThreads > 0)
            {
                lock (pcQueue)
                {
                    // Pulse the PCQueue to signal any waiting threads
                    Monitor.Pulse(pcQueue);
                }
            }

            // Iterate through producers and signal them to finish
            foreach (var p in producers)
            {
                p.Finished = true;
            }

            // Wait for all producers to finish
            while (Producer.RunningThreads > 0)
            {
                lock (pcQueue)
                {
                    // Pulse the PCQueue to signal any waiting threads
                    Monitor.Pulse(pcQueue);
                }
            }
        }

        public void DisplayDrivers()
        {
            // Clear any items in listbox
            driverListbox.Items.Clear();

            // Having finished generating data we can now display driver data on form
            foreach (var driver in driverList.Drivers)
            {
                driverListbox.Items.Add(driver);
            }
        }

        public void DisplayAlphabets()
        {
            // Clear any items in listbox
            dateListbox.Items.Clear();

            // Having finished generating data we can now display driver data on form
            foreach (var driver in driverList.CalculateAlphabet())
            {
                dateListbox.Items.Add(driver);
            }

        }
        public void DisplayDates()
        {
            // Clear any items in listbox
            dateListbox.Items.Clear();

            // Having finished generating data we can now display driver data on form
            foreach (var date in driverList.CalculateDateDistances())
            {
                dateListbox.Items.Add(date);
            }
        }

        public void DisplayLongest()
        {
            journeyListbox.Items.Clear();

            foreach(var v in driverList.CalculateLongest())
            {
                journeyListbox.Items.Add(v);
            } 

        }

        private void configBtn_Click(object sender, EventArgs e)
        {
            // Clear any items in listbox
            driverListbox.Items.Clear();

            SetupConfigData();

            // Update form object properties
            progressLbl.Text = "Config data loaded. Waiting for user to press load";
            RunProducerConsumerBtn.Enabled = true;
            driverBtn.Enabled = false;
            datesBtn.Enabled = false;
            AlphabetBtn.Enabled = false;  
            longestBtn.Enabled = false; 
            configBtn.Enabled = false;
        }

        private void RunProducerConsumerBtn_Click(object sender, EventArgs e)
        {
            // Clear any items in listbox
            driverListbox.Items.Clear();

            progressLbl.Text = "Running producer/consumer queue...";
            progressLbl.Refresh();

            // Run producer/consumer queue to load driver data
            RunProducerConsumer();

            // Update form object properties
            progressLbl.Text = "Journey data loaded";
            driverBtn.Enabled = true;
            datesBtn.Enabled = true;
            AlphabetBtn.Enabled = true;
            longestBtn.Enabled= true;
            RunProducerConsumerBtn.Enabled = false;
        }

        private void driversBtn_Click(object sender, EventArgs e)
        {
            DisplayDrivers();
        }

        private void AlphabetBtn_Click(object sender, EventArgs e)
        {
            DisplayAlphabets();
        }
        private void datesBtn_Click(object sender, EventArgs e)
        {
            DisplayDates();
        }
        private void longestBtn_Click(object sender, EventArgs e)
        {
            DisplayLongest();
        }

        private void driverListbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Clear any items in listbox
            journeyListbox.Items.Clear();

            var driver = (Driver)driverListbox.SelectedItem;

            // Having finished generating data we can now display date data on form
            foreach (var c in driver.Journeys)
            {
                journeyListbox.Items.Add(c);
            }
        }

    }
}
