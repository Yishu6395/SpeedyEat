﻿namespace SpeedyEat
{
    public class Work
    {
        public ConfigRecord configRecord { get; } // Data used when this work is processed - config record
        private IDriverFileReader IOhandler; // Data used when this work is processed - config record

        public Work(ConfigRecord data, IDriverFileReader IOhandler)
        {
            this.configRecord = data; // Data is initialised when the work is instantiated
            this.IOhandler = IOhandler;
        }

        public Driver ReadData()
        {
            // Reads the specified file and extracts the constituency data from it to store in a Constituency object
            return IOhandler.ReadDriverDataFromFile(configRecord);
        }
    }
}
