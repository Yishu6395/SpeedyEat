﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System; 
using System.Collections.Generic;
using System.Linq;

namespace UnitTestProject1
{
    class Journey
    {
        public String Date { get; set; }
        public String Collection { get; set; }
        public String Delivery { get; set; }
        public int Distances { get; set; }

        public Journey(String date, String collection, String delivery, int distances)
        {
            this.Date = date;
            this.Collection = collection;
            this.Delivery = delivery;
            this.Distances = distances;
        }

        public override String ToString()
        {
            return string.Format("{0}: {1}, {2}, {3}", this.Date, this.Collection, this.Delivery, this.Distances);
        }
    }
    class Driver
    {
        public String Name { get; set; }
        public int longestDistance { get; set; }
        public String longestDate { get; set; }

        public List<Journey> Journeys { get; set; }

        public Driver(String name, int longestDistance, String longestDate)
        {
            this.Name = name;
            this.Journeys = new List<Journey>();
            this.longestDistance = longestDistance;
            this.longestDate = longestDate;
        }

        public override String ToString()
        {
            return String.Format("Driver: {0}", this.Name);
        }
    }

    class DriverList
    {
        public List<Driver> Drivers { get; set; }

        public DriverList()
        {
            this.Drivers = new List<Driver>();
        }

        public List<String> CalculateLongest()
        {
            var dist = 0;
            var date = "";
            var name = "";

            foreach (var driver in this.Drivers)
            {
                if (dist < driver.longestDistance)
                {
                    dist = driver.longestDistance;
                    date = driver.longestDate;
                    name = driver.Name;
                }
            }
            List<String> ans = new List<String>();
            ans.Add("Longest Distance up till now ");
            ans.Add(String.Format("Driver Name : {0}", name));
            ans.Add(String.Format("Distance = {0}", dist));
            ans.Add(String.Format("Date : {0}", date));
            return ans;

        }
    }
        [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            Driver d1 = new Driver("Alex", 0, "");
            Driver d2 = new Driver("Bob", 0, "");
            Driver d3 = new Driver("Catherine", 0, "");
            Driver d4 = new Driver("David", 0, "");
            DriverList dl = new DriverList();
            Journey j1 = new Journey("21/3/2009", "bed1", "NHU 6781", 989);
            Journey j2 = new Journey("20/7/2016", "bed2", "NHU 6782", 569);
            Journey j3 = new Journey("22/9/2019", "bed3", "NHU 6783", 9965);
            Journey j4 = new Journey("1/12/2010", "bed4", "NHU 6784", 9893);
            Journey j5 = new Journey("11/11/2009", "bed5", "NHU 6785", 3589);
            Journey j6 = new Journey("4/11/2010", "bed6", "NHU 6786", 260);
            Journey j7 = new Journey("29/5/2011", "bed7", "NHU 6787", 9);
            Journey j8 = new Journey("10/6/2003", "bed8", "NHU 6788", 3489);
            Journey j9 = new Journey("7/6/2001", "bed9", "NHU 6789", 8789);
            Journey j10 = new Journey("21/4/2009", "bed10", "NHU 6780", 347);

            dl.Drivers.Add(d1); dl.Drivers.Add(d2);
            dl.Drivers.Add(d3); dl.Drivers.Add(d4);
            d1.Journeys.Add(j1);
            if(j1.Distances > d1.longestDistance)
            {
                d1.longestDistance = j1.Distances;
                d1.longestDate = j1.Date;
            }
            d1.Journeys.Add(j5);
            if (j5.Distances > d1.longestDistance)
            {
                d1.longestDistance = j5.Distances;
                d1.longestDate = j5.Date;
            }
            d1.Journeys.Add(j8);
            if (j8.Distances > d1.longestDistance)
            {
                d1.longestDistance = j8.Distances;
                d1.longestDate = j8.Date;
            }
            d2.Journeys.Add(j2);
            if (j2.Distances > d2.longestDistance)
            {
                d2.longestDistance = j2.Distances;
                d2.longestDate = j2.Date;
            }
            d2.Journeys.Add(j6);
            if (j6.Distances > d2.longestDistance)
            {
                d2.longestDistance = j6.Distances;
                d2.longestDate = j6.Date;
            }
            d2.Journeys.Add(j9);
            if (j9.Distances > d2.longestDistance)
            {
                d2.longestDistance = j9.Distances;
                d2.longestDate = j9.Date;
            }
            List<String> ans = dl.CalculateLongest();
            Assert.AreEqual("Distance = 8789", ans[2]);
            d3.Journeys.Add(j3);
            if (j3.Distances > d3.longestDistance)
            {
                d3.longestDistance = j3.Distances;
                d3.longestDate = j3.Date;
            }
            d3.Journeys.Add(j7);
            if (j7.Distances > d3.longestDistance)
            {
                d3.longestDistance = j7.Distances;
                d3.longestDate = j7.Date;
            }
            d4.Journeys.Add(j10);
            if (j10.Distances > d4.longestDistance)
            {
                d4.longestDistance = j10.Distances;
                d4.longestDate = j10.Date;
            }
            d4.Journeys.Add(j4);
            if (j4.Distances > d4.longestDistance)
            {
                d4.longestDistance = j4.Distances;
                d4.longestDate = j4.Date;
            }
            
            List<String> ans2 = dl.CalculateLongest();
            Assert.AreEqual("Distance = 9965", ans2[2]); 
            
        }
    }
    
}
